import sys
sys.argv = ['E:\\MIST\\L-4 T-1\\CSE-400 Project and Thesis\\python\\char classification final thesis\\0003.jpg']
execfile('E:\\MIST\\L-4 T-1\\CSE-400 Project and Thesis\\python\\char classification final thesis\\make_prediction.py')